var _driver___common_8h =
[
    [ "ARM_DRIVER_ERROR", "group__hal.html#ga2f627075447749bb368d3b768be107cb", null ],
    [ "ARM_DRIVER_ERROR_BUSY", "group__hal.html#ga13c1123319c7b9a4735d63447f35116b", null ],
    [ "ARM_DRIVER_ERROR_PARAMETER", "group__hal.html#gac781d4b70ce17c4c2efe2db045be751c", null ],
    [ "ARM_DRIVER_ERROR_SPECIFIC", "group__hal.html#ga5a2b5d68f6649598d099b88c0eaee3e5", null ],
    [ "ARM_DRIVER_ERROR_TIMEOUT", "group__hal.html#ga0bac892205bb2d586b822e8b178ab310", null ],
    [ "ARM_DRIVER_ERROR_UNSUPPORTED", "group__hal.html#ga2efa59e480d82697795439220e6884e4", null ],
    [ "ARM_DRIVER_OK", "group__hal.html#ga85752c5de59e8adeb001e35ff5be6be7", null ],
    [ "ARM_DRIVER_VERSION_MAJOR_MINOR", "group__hal.html#ga43c7ca1eb0786d818624246c09932a74", null ],
    [ "ARM_DRIVER_VERSION", "group__hal.html#ga2da88098fab5461030c0eadee5b60df0", null ],
    [ "ARM_POWER_STATE", "group__hal.html#gaca1989b79e945ae368c00524b6e169fd", null ],
    [ "_ARM_POWER_STATE", "group__hal.html#ga32935b3f64876043bdfa1cab4aa03a29", [
      [ "ARM_POWER_OFF", "group__hal.html#gga32935b3f64876043bdfa1cab4aa03a29ab6f5becc85ebd51c3dd2524a95d2ca35", null ],
      [ "ARM_POWER_LOW", "group__hal.html#gga32935b3f64876043bdfa1cab4aa03a29a9ef9e57cbcc948d0e22314e73dc8c434", null ],
      [ "ARM_POWER_FULL", "group__hal.html#gga32935b3f64876043bdfa1cab4aa03a29abed52b77a9ce4775570e44a842b1295e", null ]
    ] ]
];