var _m_m_a8451_q_8cpp =
[
    [ "REG_CTRL_REG_1", "_m_m_a8451_q_8cpp.html#aeafec231eb5fb0fe07cd33a9e7813574", null ],
    [ "REG_OUT_X_MSB", "_m_m_a8451_q_8cpp.html#a62c3fcf167c1c4188b03bf6db3ab7412", null ],
    [ "REG_OUT_Y_MSB", "_m_m_a8451_q_8cpp.html#a21e89c10c4c5073a96fb4c8cffb2236d", null ],
    [ "REG_OUT_Z_MSB", "_m_m_a8451_q_8cpp.html#a1861315e9b10c812a2b124903ec919a9", null ],
    [ "REG_WHO_AM_I", "_m_m_a8451_q_8cpp.html#a73f4728dfb5c82afcea7bee729af205c", null ],
    [ "UINT14_MAX", "_m_m_a8451_q_8cpp.html#a7bb2a0c78ec084975bccc12356548ac1", null ]
];