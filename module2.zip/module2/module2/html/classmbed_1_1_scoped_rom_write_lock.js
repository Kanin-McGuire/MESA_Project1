var classmbed_1_1_scoped_rom_write_lock =
[
    [ "ScopedRomWriteLock", "classmbed_1_1_scoped_rom_write_lock.html#ae98d6070b6b3a6ccfcdfa0cfe4402477", null ],
    [ "~ScopedRomWriteLock", "classmbed_1_1_scoped_rom_write_lock.html#af224f6d4729ecc3aa9711c7a71307bf1", null ]
];