var _file_base_8h =
[
    [ "FILEHANDLE", "_file_base_8h.html#ae3c686f9cfb2c0113bc42a8c3f7f26b6", null ],
    [ "PathType", "_file_base_8h.html#a14f9fc5a056230139f48f580d5429528", [
      [ "FilePathType", "_file_base_8h.html#a14f9fc5a056230139f48f580d5429528aae21aa06867affca61853523b4194efc", null ],
      [ "FileSystemPathType", "_file_base_8h.html#a14f9fc5a056230139f48f580d5429528a7e3447f48b14f3c9fb31d7ec1bac0364", null ]
    ] ]
];