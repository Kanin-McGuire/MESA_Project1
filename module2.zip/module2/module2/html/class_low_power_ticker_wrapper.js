var class_low_power_ticker_wrapper =
[
    [ "LowPowerTickerWrapper", "class_low_power_ticker_wrapper.html#a390dd2ee0837af1a6daa77ac535179b0", null ],
    [ "clear_interrupt", "class_low_power_ticker_wrapper.html#a4e91205d385fa7644997b318950a93e7", null ],
    [ "disable_interrupt", "class_low_power_ticker_wrapper.html#a92f885395769f73876095acb94e35860", null ],
    [ "fire_interrupt", "class_low_power_ticker_wrapper.html#aed8c16e54d5b495124f4e391b401452c", null ],
    [ "free", "class_low_power_ticker_wrapper.html#a9e31f061d922794b9b6b9c96484afd96", null ],
    [ "get_info", "class_low_power_ticker_wrapper.html#a0c90295c29db6c140ff1ba661d8408c9", null ],
    [ "init", "class_low_power_ticker_wrapper.html#a15e3d050a41843bec6c2807db9241210", null ],
    [ "irq_handler", "class_low_power_ticker_wrapper.html#ab7c486041365546e70a6a289a68754a0", null ],
    [ "read", "class_low_power_ticker_wrapper.html#a3590426fa8d368336762101afd83e9d6", null ],
    [ "resume", "class_low_power_ticker_wrapper.html#a4d76eb0ed5957f6fc4d7e05160be42b1", null ],
    [ "set_interrupt", "class_low_power_ticker_wrapper.html#a5352b70ecf087515f49a6323077a9cb2", null ],
    [ "suspend", "class_low_power_ticker_wrapper.html#a0823ee66d9e5640e44847d8b282f06c1", null ],
    [ "timeout_pending", "class_low_power_ticker_wrapper.html#a5f726891c87f06fe2e50c8f663778951", null ],
    [ "data", "class_low_power_ticker_wrapper.html#a6ba19dde266b9a3fa0a5a3dfea34ac11", null ]
];