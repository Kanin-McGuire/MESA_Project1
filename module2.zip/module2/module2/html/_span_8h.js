var _span_8h =
[
    [ "is_convertible", "classmbed_1_1span__detail_1_1is__convertible.html", null ],
    [ "SPAN_DYNAMIC_EXTENT", "group__platform___span.html#gad0090058d9cb5eca53fe5fda0207342a", null ],
    [ "make_const_Span", "_span_8h.html#ga639222d6cbc96676347d21b59e20321f", null ],
    [ "make_Span", "_span_8h.html#gaed694ced84b1e4c58a2291849fcde2f4", null ],
    [ "operator!=", "_span_8h.html#ga3d0d34c3a233bc38f76624b8ee555ea0", null ],
    [ "operator!=", "_span_8h.html#gae665fa6f7b3e11015c17c40dcf8ca75f", null ],
    [ "operator==", "_span_8h.html#ga5ef97921e0671d78e6f97017e73d01d1", null ],
    [ "operator==", "_span_8h.html#gabfad3f7d020160d758777177868d87d0", null ]
];