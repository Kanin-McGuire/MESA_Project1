var cmsis__nvic_8h =
[
    [ "NVIC_NUM_VECTORS", "cmsis__nvic_8h.html#aabda131b2f01e9aa52b49477300bddf6", null ],
    [ "NVIC_RAM_VECTOR_ADDRESS", "cmsis__nvic_8h.html#a658c2e61187a2e0a2c24d24fff527a5d", null ]
];