var files_dup =
[
    [ "mbed", "dir_746369e733900accdb87dbe74aa188c4.html", "dir_746369e733900accdb87dbe74aa188c4" ],
    [ "MMA8451Q", "dir_a3ee9197c495a0a9514b44efa7051738.html", "dir_a3ee9197c495a0a9514b44efa7051738" ],
    [ "TSI", "dir_2740f1722b7a5b28f453c61c5f1f57ba.html", "dir_2740f1722b7a5b28f453c61c5f1f57ba" ],
    [ "main.cpp", "main_8cpp.html", "main_8cpp" ],
    [ "mbed_config.h", "mbed__config_8h.html", "mbed__config_8h" ]
];