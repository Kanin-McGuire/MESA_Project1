var dir_a3ee9197c495a0a9514b44efa7051738 =
[
    [ "MMA8451Q.cpp", "_m_m_a8451_q_8cpp.html", "_m_m_a8451_q_8cpp" ],
    [ "MMA8451Q.h", "_m_m_a8451_q_8h.html", [
      [ "MMA8451Q", "class_m_m_a8451_q.html", "class_m_m_a8451_q" ]
    ] ]
];