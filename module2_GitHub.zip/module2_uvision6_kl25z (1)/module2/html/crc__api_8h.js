var crc__api_8h =
[
    [ "crc_mbed_config_t", "group__hal.html#gac9890e7b0044fa0631a3a669b5517487", null ],
    [ "crc_polynomial_t", "group__hal.html#gaaa1fa2bb611c113fa66e2c3e02f82f37", null ],
    [ "crc_polynomial", "group__hal.html#gaac29aaabcf8b2e9348a5a2a730fdf46a", [
      [ "POLY_OTHER", "group__hal.html#ggaac29aaabcf8b2e9348a5a2a730fdf46aa65a49bc558ee612a7c9a37d9519da794", null ],
      [ "POLY_8BIT_CCITT", "group__hal.html#ggaac29aaabcf8b2e9348a5a2a730fdf46aa11f0187e6192505aec2bf4269c26d5ea", null ],
      [ "POLY_7BIT_SD", "group__hal.html#ggaac29aaabcf8b2e9348a5a2a730fdf46aa7fb8f90dfd5ee3cd5b2767bac79ae99d", null ],
      [ "POLY_16BIT_CCITT", "group__hal.html#ggaac29aaabcf8b2e9348a5a2a730fdf46aae788c7d08ed51c9e1fba9bc3295a13c6", null ],
      [ "POLY_16BIT_IBM", "group__hal.html#ggaac29aaabcf8b2e9348a5a2a730fdf46aa892af83ad6b24294e7d82e1a5ac87509", null ],
      [ "POLY_32BIT_ANSI", "group__hal.html#ggaac29aaabcf8b2e9348a5a2a730fdf46aaf75299fa9ab0db23269d0f43bb7a0f45", null ],
      [ "POLY_32BIT_REV_ANSI", "group__hal.html#ggaac29aaabcf8b2e9348a5a2a730fdf46aa967ef9c15654a73d0ae6669fbeabb0fb", null ]
    ] ]
];