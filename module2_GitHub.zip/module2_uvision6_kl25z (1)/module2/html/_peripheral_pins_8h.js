var _peripheral_pins_8h =
[
    [ "PinMap_ADC", "_peripheral_pins_8h.html#a9a368cf73e86842f01d50df63f3ddb14", null ],
    [ "PinMap_DAC", "_peripheral_pins_8h.html#acc42eb246b27cf0b7239d4454bc38c8b", null ],
    [ "PinMap_I2C_SCL", "_peripheral_pins_8h.html#af57c1b27833803096e47556c34c25a8a", null ],
    [ "PinMap_I2C_SDA", "_peripheral_pins_8h.html#a958ccea6b63e24bff59aa5257d7f2f4f", null ],
    [ "PinMap_PWM", "_peripheral_pins_8h.html#a8bd443a991a92a112902e0fb8aa15a4d", null ],
    [ "PinMap_RTC", "_peripheral_pins_8h.html#ac75bdde88ba7ac8f537ed5e690fd4eea", null ],
    [ "PinMap_SPI_MISO", "_peripheral_pins_8h.html#abeacad658e5c5e3c498434d5e5534641", null ],
    [ "PinMap_SPI_MOSI", "_peripheral_pins_8h.html#ae87548240a04ad2bb78a1ab10c976b51", null ],
    [ "PinMap_SPI_SCLK", "_peripheral_pins_8h.html#a9b48916ea58fa87935f9408d638a8d44", null ],
    [ "PinMap_SPI_SSEL", "_peripheral_pins_8h.html#af239ab425dbee8c58d54eff6158098be", null ],
    [ "PinMap_UART_RX", "_peripheral_pins_8h.html#acaf56e9c60bed7c834ae0d48d38addbc", null ],
    [ "PinMap_UART_TX", "_peripheral_pins_8h.html#ac1e283006e77bfe6376adcc330d18bb8", null ]
];