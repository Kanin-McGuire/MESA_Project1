var device_8h =
[
    [ "DEVICE_ID_LENGTH", "device_8h.html#a7abb2ca6966aaebe7639bb7b28829405", null ]
];