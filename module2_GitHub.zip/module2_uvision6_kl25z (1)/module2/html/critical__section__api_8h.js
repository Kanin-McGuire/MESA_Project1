var critical__section__api_8h =
[
    [ "hal_critical_section_enter", "group__hal__critical.html#ga5611a3dc748ee20ac04546d5cdcff486", null ],
    [ "hal_critical_section_exit", "group__hal__critical.html#gaa914189c6fa099435baf1e54211e73f9", null ],
    [ "hal_in_critical_section", "group__hal__critical.html#ga7b74f0b326906ec6346864517399a340", null ]
];