var class_m_m_a8451_q =
[
    [ "MMA8451Q", "class_m_m_a8451_q.html#a59430cfeb113615458a2b73fdc7391e9", null ],
    [ "~MMA8451Q", "class_m_m_a8451_q.html#add2fade85a24b3c6ae7cc489a04ba009", null ],
    [ "getAccAllAxis", "class_m_m_a8451_q.html#a6d7892d095e4f697b6f50ebc3d4b4cfc", null ],
    [ "getAccX", "class_m_m_a8451_q.html#a9226a2f00edef47be520ecca28d6a425", null ],
    [ "getAccY", "class_m_m_a8451_q.html#a365e88d07f16faa9da4183f34055b4a5", null ],
    [ "getAccZ", "class_m_m_a8451_q.html#afb63783e2e4d3af92229dd0311905132", null ],
    [ "getWhoAmI", "class_m_m_a8451_q.html#adbf87f413cfa95e88d49990b2a4af6d4", null ]
];