var class_t_s_i_sensor =
[
    [ "TSISensor", "class_t_s_i_sensor.html#a7ec8913197ba2783cd2f9f72d03d7a1d", null ],
    [ "readDistance", "class_t_s_i_sensor.html#a6e36b2b1a6b84186e1e0e0b582d66242", null ],
    [ "readPercentage", "class_t_s_i_sensor.html#ae07076ceaf94ecd1d31f7b8ac09772ee", null ]
];