var dir_2740f1722b7a5b28f453c61c5f1f57ba =
[
    [ "TSISensor.cpp", "_t_s_i_sensor_8cpp.html", "_t_s_i_sensor_8cpp" ],
    [ "TSISensor.h", "_t_s_i_sensor_8h.html", [
      [ "TSISensor", "class_t_s_i_sensor.html", "class_t_s_i_sensor" ]
    ] ]
];