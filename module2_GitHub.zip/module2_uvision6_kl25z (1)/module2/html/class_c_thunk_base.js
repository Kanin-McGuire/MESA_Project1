var class_c_thunk_base =
[
    [ "Trampoline", "class_c_thunk_base.html#ac3907957afdbb0f2201e35fb265df28f", null ],
    [ "_trampoline", "class_c_thunk_base.html#ae994dc770d5aa87eafff0afe9bdc49d5", null ]
];