var buffer_8h =
[
    [ "buffer_t", "group__hal.html#ga81b62558b8599f883304a26b742aa44f", null ]
];