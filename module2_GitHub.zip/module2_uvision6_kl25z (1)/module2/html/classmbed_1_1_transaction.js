var classmbed_1_1_transaction =
[
    [ "Transaction", "classmbed_1_1_transaction.html#a8f185640162870544484447dddb655f3", null ],
    [ "Transaction", "classmbed_1_1_transaction.html#aaca5861c4d5ccc9f8b2f06e7902282da", null ],
    [ "~Transaction", "classmbed_1_1_transaction.html#a3857203265a13e9aad8ae467f88bf495", null ],
    [ "get_object", "classmbed_1_1_transaction.html#a1cc189ffc187d991feada5305f895c94", null ],
    [ "get_transaction", "classmbed_1_1_transaction.html#a3f1bb2429fab5588c7127d640ea35236", null ]
];