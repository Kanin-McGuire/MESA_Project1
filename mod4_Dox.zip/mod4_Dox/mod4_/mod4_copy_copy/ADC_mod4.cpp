/**----------------------------------------------------------------------------
 
   \file ADC_mod4.cpp
--                                                                           --
--              IGNORE THIS FILE THIS FILE WAS USED FOR TEMPORARY TESTING
*/

////#include "shared.h"
//#include "sample_input.h"

//AnalogIn VREFL(PTB0);
//AnalogIn Vortex(PTB1);
//AnalogIn TempSensor(PTB2);

//uint32_t sample = 0;
//extern int16_t vortex_input[];
//uint16_t adc_read(uint16_t channel);
//void adc_calibrate(){

//			// Enable clocks
//			SIM->SCGC6 |= SIM_SCGC6_ADC0_MASK;   // ADC 0 clock
//			
//			ADC0->CFG1 &= ~ADC_CFG1_ADLPC_MASK; //Low Power Config
//			ADC0->CFG1 |= ADC_CFG1_ADLSMP_MASK; //Long sample time
//			ADC0->CFG1 &= ~ADC_CFG1_ADIV_MASK; // clock divider of 1
//		  ADC0->CFG1 &= ~ADC_CFG1_ADICLK_MASK; // Input Bus Clock
//			ADC0->CFG1 &= ADC_CFG1_MODE_MASK;
//			ADC0->SC1[0] &= ~ADC_SC1_ADCH_MASK;
//			ADC0->SC1[0] |= 0b11010;
//	
////			ADC0->CFG2 = 	(0 & ADC_CFG2_ADHSC_MASK) | // 1 High-speed conversion sequence, 0 for normal coversion, zero as sampling is 10 usec, bus clock is good enought
////										(0 & ADC_CFG2_ADLSTS_MASK) | // Default longest sample time of an extra 20 ADCK cycles so 24 total
////										(0 & ADC_CFG2_ADACKEN_MASK);
//			
////			ADC0->SC3 = (1 & ADC_SC3_AVGE_MASK);//Hardware average enable/disable
//			ADC0->SC2 = (0 & ADC_SC2_ADTRG_MASK);//Hardware average select
//			ADC0->SC3 |= ( ADC_SC3_CAL_MASK);//begin calibration

//			while (!((ADC0->SC1[0] & ADC_SC1_COCO_MASK) >> ADC_SC1_COCO_SHIFT)); // wait for completion
//			if ((ADC0->SC3 &  ADC_SC3_CALF_MASK) >> ADC_SC3_CALF_SHIFT);	
////	
//			uint16_t PG = 0; 
//			uint16_t MG = 0; 
//			
//			PG = (ADC0->CLP0)+(ADC0->CLP1)+(ADC0->CLP2)+(ADC0->CLP3)+(ADC0->CLP4)+(ADC0->CLPS); 
//			PG = PG/2; // Divide by 2
//			PG|=0x8000; //Set the MSB
//			ADC0->PG = PG; //Store the value
//			
//			MG = (ADC0->CLM0)+(ADC0->CLM1)+(ADC0->CLM2)+(ADC0->CLM3)+(ADC0->CLM4)+(ADC0->CLMS); 
//			MG = MG/2; //Divide by 2
//			MG |= 0x8000; //Set the MSB
//			ADC0->MG = MG; //Store the value
//}




//uint16_t adc_read(uint16_t channel){
////	SIM->SCGC6 |= SIM_SCGC6_ADC0_MASK;   // ADC 0 clock
////	ADC0->CFG1 = 0;
////	ADC0->CFG1 |= ((0 & ADC_CFG1_ADLPC_MASK) | //Low Power Config
////									(1 & ADC_CFG1_ADLSMP_MASK) | //Long sample time
////                 ADC_CFG1_ADICLK(0)|   // Input Bus Clock
////                 ADC_CFG1_ADIV(0));  // clock divider of 1
////	ADC0->CFG2 = 	(0 & ADC_CFG2_ADHSC_MASK) | // 1 High-speed conversion sequence, 0 for normal coversion, zero as sampling is 10 usec, bus clock is good enought
////								(0 & ADC_CFG2_ADLSTS_MASK) | // Default longest sample time of an extra 20 ADCK cycles so 24 total
////								(0 & ADC_CFG2_ADACKEN_MASK);	
//	
//	if(channel == 0){
//			// Enable clocks
////			SIM->SCGC6 |= SIM_SCGC6_ADC0_MASK;   // ADC 0 clock
//			
////			ADC0->CFG1 = 0;
//			ADC0->CFG1 |= ADC_CFG1_MODE(0);
////		((0 & ADC_CFG1_ADLPC_MASK) | //Low Power Config
////									(1 & ADC_CFG1_ADLSMP_MASK) | //Long sample time
////								 ADC_CFG1_MODE(0)|   // 8 bit conversion mode
////                 ADC_CFG1_ADICLK(0)|   // Input Bus Clock
////                 ADC_CFG1_ADIV(0));  // clock divider of 1
//			
////			ADC0->CFG2 = 	(0 & ADC_CFG2_ADHSC_MASK) | // 1 High-speed conversion sequence, 0 for normal coversion, zero as sampling is 10 usec, bus clock is good enought
////										(0 & ADC_CFG2_ADLSTS_MASK) | // Default longest sample time of an extra 20 ADCK cycles so 24 total
////										(0 & ADC_CFG2_ADACKEN_MASK);
//			
//			ADC0->SC3 = (0 & ADC_SC3_ADCO_MASK);//0 for non continuous, 1 for continuous
//			
//			ADC0->SC1[0] = ADC_SC1_ADCH(30) | (0 & ADC_SC1_DIFF_MASK); // channel 30 VREFL 0 Diff for single ended conversions
//			
//			Vrefl = VREFL.read_u16();
//		return (Vref1);
//		}
//		
//		if(channel == 1){
//			// Enable clocks
////			SIM->SCGC6 |= SIM_SCGC6_ADC0_MASK;   // ADC 0 clock
////			
////			ADC0->CFG1 = 0;
//			ADC0->CFG1 |= ADC_CFG1_MODE(3);
////			((0 & ADC_CFG1_ADLPC_MASK) | //Low Power Config
////									(1 & ADC_CFG1_ADLSMP_MASK) | //Long sample time
////								 ADC_CFG1_MODE(3)|   // 16 bit conversion mode
////                 ADC_CFG1_ADICLK(0)|   // Input Bus Clock
////                 ADC_CFG1_ADIV(0));  // clock divider of 1
//			
////			ADC0->CFG2 = 	(0 & ADC_CFG2_ADHSC_MASK) | // 1 High-speed conversion sequence, 0 for normal coversion, zero as sampling is 10 usec, bus clock is good enought
////										(0 & ADC_CFG2_ADLSTS_MASK) | // Default longest sample time of an extra 20 ADCK cycles so 24 total
////										(0 & ADC_CFG2_ADACKEN_MASK);
//			
//			ADC0->SC3 = (1 & ADC_SC3_ADCO_MASK);//0 for non continuous, 1 for continuous
//			
//			ADC0->SC1[0] = ADC_SC1_ADCH(9) | (0 & ADC_SC1_DIFF_MASK); // channel 9 Flow input 0 Diff for single ended conversions
//			
//			if(sample < 1000){
//			ADC_freq = vortex_input[sample] + (Vortex.read_u16());
//			sample = sample + 1;
//				return sample;
//			}
//		}
//				
//		if(channel == 2){
//			// Enable clocks
////			SIM->SCGC6 |= SIM_SCGC6_ADC0_MASK;   // ADC 0 clock
////			
////			ADC0->CFG1 = 0;
//			ADC0->CFG1 |= ADC_CFG1_MODE(3);
////			((0 & ADC_CFG1_ADLPC_MASK) | //Low Power Config
////									(1 & ADC_CFG1_ADLSMP_MASK) | //Long sample time
////								 ADC_CFG1_MODE(3)|   // 16 bit conversion mode
////                 ADC_CFG1_ADICLK(0)|   // Input Bus Clock
////                 ADC_CFG1_ADIV(0));  // clock divider of 1
//			
////			ADC0->CFG2 = 	(0 & ADC_CFG2_ADHSC_MASK) | // 1 High-speed conversion sequence, 0 for normal coversion, zero as sampling is 10 usec, bus clock is good enought
////										(0 & ADC_CFG2_ADLSTS_MASK) | // Default longest sample time of an extra 20 ADCK cycles so 24 total
////										(0 & ADC_CFG2_ADACKEN_MASK);
//			
//			ADC0->SC3 = (1 & ADC_SC3_ADCO_MASK);//0 for non continuous, 1 for continuous
//			
//			ADC0->SC1[0] = ADC_SC1_ADCH(26) | (0 & ADC_SC1_DIFF_MASK); // channel 26 temp sensor 0 Diff for single ended conversions
//		
//			Vtemp = (float)TempSensor.read();
//			return (Vtemp);
//		}

//}

