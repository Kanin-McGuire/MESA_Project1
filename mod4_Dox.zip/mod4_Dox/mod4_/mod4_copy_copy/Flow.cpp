/**----------------------------------------------------------------------------
 
   \file Flow.cpp
--                                                                           --
--              ECEN 5803 Mastering Embedded System Architecture             --
--                  Project 1 Module 4                                       --
--                Microcontroller Firmware                                   --
--                      Flow.cpp                                             --
--                                                                           --
-------------------------------------------------------------------------------
--
--  Designed by:  Kanin and Maitreyee
*/
#include "shared.h"

bool positive;
bool start = FALSE;
uint16_t zero = 0;
uint16_t threshold = 5000;//play with value based on results
uint16_t num_checks = 0; //records the number of samples checked since clear

 /**
 * @brief Frequency Function
 *
 * The function take in sampled inputs and then it will count the number of Zero crossings plus some threshold
 * to find the frequency. There are 1000 samples so the Zero value is divided by 0.1 because 1000 samples sampled 
 * at 100 us seconds gets us 0.1
 *
 * @return
 *  Void: The Frequency value is placed in a global variable.
 * 
 */
void Frequency(){

	num_checks = 0;
	zero = 0;
		//num_checks += 1;
    while(num_checks < 1000){
		if(start == FALSE){
			start = TRUE;
			if(vortex_input[0] > 0)positive = TRUE;
			else positive = FALSE;
		}
		
		if((positive == TRUE) && (vortex_input[num_checks] < (0x7CC6-threshold))){
				positive = FALSE;
				zero = zero + 1;
		}
		else{ 
				if ((positive == FALSE) && (vortex_input[num_checks] > (0x7CC6 + threshold))){
						positive = TRUE;
						zero = zero + 1;
				}
		}
		num_checks += 1;
	}
		//start = false;
		freq_value = zero/(0.1*2);//((zero*SEC)/(num_checks*2));//sum/8;
}

 /**
 * @brief Flow Calculation
 *
 * The flow calculation function uses the Temperature and the Frequency to calculate the flow.
 *
 * @return
*  Void: Flow is written to a Global variable.
 * 
 */
void Flow(){   

    double d = .5; //% inches
    double PID =  2.9; //% inches
    uint8_t v = 10;
    double rho, viscosity, Re, St;

		
		for(int i = 0; i < 5; i++){
        rho = 1000*(1 - ((T+288.9414)/(508929.2*(T+68.12963)))*((T-3.9863)*(T-3.9863)));
        //%in kg/m^3 with T In degrees C.
        viscosity = (2.4 * (0.00001)) * pow(10.0,(247.8/((T+273.15)-140.0)));//10^(247.8/((T+273.15)-140.0)); //% t from cel to kelvin 
        //%kg/(m*s) = V T is in Kelvin
        Re = (rho * v * (PID*.0254)) / viscosity;
        double k = sqrt(double(Re));//sqrt(Re);
        St = .02684 - (1.0356/k);
        v = ((freq_value*(d))/St) * 0.0254; //%m/s
				//printf(" Velocity = %5.2f C\n\r",v);
    }
		
    flow = 2.45 * ((PID)*(PID)) * (v * 3.28084); 


}


